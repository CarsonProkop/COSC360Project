<?php
	$username = "cprokopu";
	$password = "102898";
	$database = "db_" . $username;
	$server = "sql04.ok.ubc.ca";
	$connectionInfo = array( "Database"=>$database, "UID"=>$username, "PWD"=>$password, "CharacterSet" => "UTF-8");
?>
